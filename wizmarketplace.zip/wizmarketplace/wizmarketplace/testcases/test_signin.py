#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import time
import requests
import json
import re
import unittest
from selenium import webdriver
from ddt import ddt, file_data
from selenium.webdriver import Keys
from config import get_num
from config.config import base_url


@ddt
class Test_Sign_Up(unittest.TestCase):
    def setUp(self) -> None:
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()
        self.driver.implicitly_wait(10)

    def tearDown(self) -> None:
        self.driver.quit()

    @file_data(r'../data/sign_up.yaml')
    def test_sign_up(self, case_desc, firstName, lastName, email, password, Phonenumber, expect_value):
        # 1.访问首页
        self.driver.get(base_url)
        # 2.点击注册
        self.driver.find_element('xpath', '/html//div[2]/div[3]/div[1]/div[2]/p').click()
        # 3.输入用户名，密码，点击注册
        self.driver.find_element('name', 'firstName').send_keys(firstName)
        self.driver.find_element('name', 'lastName').send_keys(lastName)
        self.driver.find_element('name', 'email').send_keys(email)
        self.driver.find_element('name', 'phoneNumber').send_keys(Phonenumber)
        self.driver.find_element('name', 'password').send_keys(password)
        self.driver.find_element('xpath', "//button[(text())='Sign up']").click()
        time.sleep(3)
        # 4.获取验证码并输入
        # We want to get account validation code in email
        validation_code = None
        # We will retry the request every 6 seconds to get the email
        for i in range(50):
            # Get emails from an email box
            req = requests.get('https://snapmail.cc/emaillist/' + email)
            if req.status_code == 200:
                # Get email text of the first email,
                # take "This is a test email." for example,
                # email_text = "This is a test email."
                email_text = json.loads(req.text)[0]['html']
                # Use regex to get the validation code, we'll get "test" here.
                # validation_code = "test"
                validation_code = re.search(r'Verification Code:\s*(\d{6})', email_text)
                break
            print("Waiting for next retry")
            time.sleep(6)
        if validation_code:
            code = validation_code.group(1)

        self.driver.find_element('xpath', '//*[@id="__next"]/div/main/div/div/div/div/div[1]/input[1]').send_keys(
            code[0])
        self.driver.find_element('xpath', '//*[@id="__next"]/div/main/div/div/div/div/div[1]/input[2]').send_keys(
            code[1])
        self.driver.find_element('xpath', '//*[@id="__next"]/div/main/div/div/div/div/div[1]/input[3]').send_keys(
            code[2])
        self.driver.find_element('xpath', '//*[@id="__next"]/div/main/div/div/div/div/div[1]/input[4]').send_keys(
            code[3])
        self.driver.find_element('xpath', '//*[@id="__next"]/div/main/div/div/div/div/div[1]/input[5]').send_keys(
            code[4])
        self.driver.find_element('xpath', '//*[@id="__next"]/div/main/div/div/div/div/div[1]/input[6]').send_keys(
            code[5])
        # 5.点击注册
        self.driver.find_element('xpath', "//button[(text())='Activate']").click()
        # 10.断言
        time.sleep(60)
        # assert_el = self.driver.find_element('xpath','/html/body/div[5]/div/h6')
        # actual_value = assert_el.text
        # assert expect_value in actual_value


if __name__ == '__main__':
    unittest.main()
