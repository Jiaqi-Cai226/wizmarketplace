import time
import unittest
from selenium import webdriver
from ddt import ddt, file_data
from selenium.webdriver import Keys
from config.config import reset_url
from bs4 import BeautifulSoup
import requests
import json

@ddt
class Test_Reset_pd(unittest.TestCase):
    def setUp(self) -> None:
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()
        self.driver.implicitly_wait(15)


    def tearDown(self) -> None:
        self.driver.quit()

    @file_data(r'../data/reset_pd.yaml')
    def test_reset_pd(self, case_desc, email, password, expect_value):
        # 1.访问重置密码页面
        self.driver.get(reset_url)
        time.sleep(3)
        # 2.输入email，点击发送邮件
        self.driver.find_element('name', 'email').send_keys(email)
        self.driver.find_element('xpath', "//button[(text())='SEND RESET LINK']").click()
        time.sleep(15)
        # 3.获取email，点击重置密码
        for i in range(50):
            req = requests.get('https://snapmail.cc/emaillist/' + email)
            if req.status_code == 200:
                email_text = json.loads(req.text)[0]['html']

                soup = BeautifulSoup(email_text, 'html.parser')

                # 查找所有<a>标签
                a_tags = soup.find_all('a')
                for a_tag in a_tags:
                    if 'Reset Password' in a_tag.get_text():
                        href_value = a_tag.get('href')

        self.driver.get(href_value)
        time.sleep(6)
        self.driver.find_element('id', 'password').send_keys(password)
        self.driver.find_element('id', 'confirmPassword').send_keys(password)
        self.driver.find_element('xpath', "//*[@id='root']/div/main/div/div/form/div[3]/button").click()

        time.sleep(6)
        # 4.断言
        element_text =self.driver.find_element('xpath', "//*[@id='root']/div/main/div/div/h2").text
        assert expect_value == element_text


if __name__ == '__main__':
    unittest.main()