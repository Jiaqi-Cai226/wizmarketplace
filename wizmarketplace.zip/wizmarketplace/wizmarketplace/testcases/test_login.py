import time
import unittest
from selenium import webdriver
from ddt import ddt, file_data
from selenium.webdriver import Keys
from config.config import login_url
@ddt
class Test_Login(unittest.TestCase):
    def setUp(self) -> None:
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()
        self.driver.implicitly_wait(10)

    def tearDown(self) -> None:
        self.driver.quit()

    @file_data(r'../data/login.yaml')
    def test_login(self, case_desc, email, password, expect_value):
        # 1.访问登录页面
        self.driver.get(login_url)
        time.sleep(6)
        # 2.输入用户名，密码，点击登录
        self.driver.find_element('name', 'email').send_keys(email)
        self.driver.find_element('name', 'password').send_keys(password)
        self.driver.find_element('xpath', "//button[(text())='Log In']").click()

        time.sleep(60)

if __name__ == '__main__':
    unittest.main()