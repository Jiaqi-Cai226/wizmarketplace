#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import unittest,time
from unittestreport import TestRunner

#生成测试报告的名称
report_name = time.strftime('%Y-%m-%d-%H-%M-%S') + '_report.html'

if __name__ == '__main__':
    #生成测试夹具，从指定目录下收集指定的文件作为测试执行的内容
    suite = unittest.defaultTestLoader.discover('./testcases',pattern='test_*.py')
    #使用TestRunner类实例化一个测试用例的执行器
    runner = TestRunner( suite,
                 filename=report_name,
                 report_dir="./reports",
                 title='测试报告',
                 tester='Jiaqi',
                 desc="Web项目测试生成的报告",
                 templates=2)
    #调用测试用例执行器的运行用例的方法：run
    #count:测试执行失败时设置的重跑次数，interval:每次重跑的间隔时间
    runner.run(count=1, interval=1)
