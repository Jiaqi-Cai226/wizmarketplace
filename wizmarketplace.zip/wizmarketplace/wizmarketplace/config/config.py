#!/usr/bin/env python3
# -*- coding:utf-8 -*-

base_url = 'https://www.wizmarketplace.com'
login_url = 'https://www.wizmarketplace.com/login'
reset_url = 'https://www.wizmarketplace.com/forget-password'
