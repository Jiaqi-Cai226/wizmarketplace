
# Code in Python
import time
import requests
import json
import re
from bs4 import BeautifulSoup


def get_verification_link(email):
    for i in range(50):
        req = requests.get('https://snapmail.cc/emaillist/' + email)
        if req.status_code == 200:
            email_text = json.loads(req.text)[0]['html']

            soup = BeautifulSoup(email_text, 'html.parser')

            # 查找所有<a>标签
            a_tags = soup.find_all('a')
            for a_tag in a_tags:
                if 'Reset Password' in a_tag.get_text():
                    href_value = a_tag.get('href')
                    print(href_value)
                    return href_value

        time.sleep(6)

    return None
get_verification_link('weguboc@snapmail.cc')

