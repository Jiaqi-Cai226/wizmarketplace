
# Code in Python
import time
import requests
import json
import re
from bs4 import BeautifulSoup

def get_verification_code(email):
    # We want to get account validation code in email
    validation_code = None
    # We will retry the request every 6 seconds to get the email
    for i in range(50):
        # Get emails from an email box
        req = requests.get('https://snapmail.cc/emaillist/' + email)
        if req.status_code == 200:
            # Get email text of the first email,
            # take "This is a test email." for example,
            # email_text = "This is a test email."
            email_text = json.loads(req.text)[0]['html']
            # Use regex to get the validation code, we'll get "test" here.
            # validation_code = "test"
            validation_code = re.search( r'Verification Code:\s*(\d{6})', email_text)
            break

        print("Waiting for next retry")
        time.sleep(6)
    if validation_code:
        print('validation_code:' + validation_code.group(1))

        code=validation_code.group(1)

        return code


get_verification_code('gaivgupakr@snapmail.cc')

